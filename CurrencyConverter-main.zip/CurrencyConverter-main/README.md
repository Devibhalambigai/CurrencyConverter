a basic react.js application to convert curreny .
