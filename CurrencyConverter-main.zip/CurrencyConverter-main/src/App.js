import React from 'react';
import './App.css';
import CurrencyConverter from './CurrencyConverter';

function App() {
    return (
        <div className="App">
            <CurrencyConverter />
        </div>
    );
}

export default App;

